Ovdje stavi PNG slike jela. Nazivi datoteka moraju biti TOČNO ovakvi
(mala slova, bez kvačica, crtica umjesto razmaka):

  img/pizza.png
  img/pomfrit.png
  img/burger.png
  img/hot-dog.png
  img/topli-sendvic.png
  img/kebab.png
  img/cevapi.png

Preporuka: kvadratne slike (npr. 600x600 px), prozirna ili tamna pozadina.
Dok slike ne dodaš, aplikacija prikazuje naziv jela kao tekst (ne ruši se).
